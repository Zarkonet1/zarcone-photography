'use client';

// The dynamic dashboard hero — replaces the old marketing hero entirely
// (2026-08-25 rebuild, per Tom's brief). Four states, computed fresh on
// every render from real schedule/gallery data — no timers, no manual
// toggle:
//
//   1. NEXT      — default. Shown whenever there's an upcoming game AND the
//                  most recent played game (if any) happened more than
//                  RECENT_GAME_WINDOW_DAYS ago. This is what makes it
//                  "transition back to promoting the next scheduled game"
//                  per the brief, instead of getting stuck showing last
//                  week's final forever.
//   2. FINAL     — shown for a short window right after a game (see the
//                  constant below) if no gallery has posted for it yet.
//   3. GALLERY   — shown in that same short window if a gallery HAS posted
//                  on/after the game date (compared via GALLERIES_2026's
//                  ISO date vs. the schedule's 'Mon, Aug 27' style date,
//                  both assumed 2026 — see toSeasonDate below).
//   4. POSTPONED — added 2026-08-27. Shown only on the game's *original*
//                  date, when a schedule entry carries a `postponedFrom`
//                  field (see lib/footballSchedule.js). Self-expires the
//                  instant the calendar rolls past that date — this
//                  component computes `now` fresh on every client render,
//                  so no redeploy is needed for it to revert to the normal
//                  NEXT state on the new date. Takes priority over NEXT/
//                  FINAL/GALLERY since it's the most time-sensitive message
//                  a visitor could see.
//
// Props are raw data, not pre-formatted strings — this component owns its
// own layout/copy per state. Pass getNextGame/getLastPlayedGame results
// from lib/teamSchedule.js and getLatestGallery's result from
// lib/footballGalleries.js directly.
import { useEffect, useState } from 'react';
import Image from 'next/image';
import styles from './NextGameHero.module.css';

// How many days after a game the hero keeps showing Final/Gallery before
// flipping back to promoting the next one. 4 days covers a Thursday game
// through the following Monday. Tune freely — this is a judgment call, not
// a sourced fact.
const RECENT_GAME_WINDOW_DAYS = 4;

// SCHEDULE_2026 dates look like 'Thu, Aug 27' with no year — this file is
// scoped to the 2026 season only (see lib/footballSchedule.js), so hardcode
// 2026 here. If this component gets reused for a future season, this needs
// to read the year from somewhere instead of assuming it.
function toSeasonDate(scheduleDateStr) {
  const stripped = scheduleDateStr.replace(/^[A-Za-z]+,\s*/, '');
  return new Date(`${stripped}, 2026`);
}

function opponentName(opponentStr) {
  return opponentStr.replace(/^(at|vs)\s+/i, '').toUpperCase();
}

export default function NextGameHero({
  nextGame,
  lastPlayedGame,
  latestGallery,
  bgPhotoSrc = null,
  // fallbackGradient: generalized 2026-08-27 — when a team has no real
  // action photo on file yet, render a plain color-gradient field instead
  // of a stock/fabricated image. Pass a CSS gradient string.
  fallbackGradient = 'linear-gradient(160deg, #1a1a1a 0%, #0a0a0a 70%)',
  // Generalized 2026-08-27 for reuse by the Mahwah Football Hub build —
  // optional, defaulting to football's original hardcoded BRHS strings, so
  // football's existing <NextGameHero /> call (no new props) keeps
  // rendering exactly as before. Other team pages pass their own values.
  teamName = 'Bridgewater-Raritan Panther Football',
  teamMatchupName = 'Bridgewater-Raritan Panthers',
  teamShortLabel = 'BRHS',
  // watermarkSrc/watermarkAlt: generalized 2026-08-27 for a team with no
  // real action photo on file — lets an official team mark sit as a
  // subtle, low-opacity watermark over the gradient fallback instead of
  // the hero reading as an empty color field. Default null keeps football
  // (which always has a real bgPhotoSrc) rendering exactly as before.
  watermarkSrc = null,
  watermarkAlt = '',
}) {
  // HYDRATION FIX (2026-08-28): this state used to be computed directly
  // from `new Date()` during render. That runs once on Vercel's server
  // (UTC) and again in the browser during hydration (the visitor's local
  // timezone) — around the UTC day rollover (~8pm ET) the two clocks land
  // on different calendar dates, so server and client picked different
  // `state` values and rendered different markup. That's a textbook React
  // hydration mismatch (errors #425/#418/#423), confirmed reproducing on
  // this exact page. Fix: render the deterministic 'next' default on both
  // the server and the client's first pass (guaranteed to match, since
  // neither reads the clock), then compute the real, time-dependent state
  // client-side only, after mount, via useEffect — a normal post-hydration
  // state update, which React never diffs against the server HTML.
  const [state, setState] = useState('next');

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const now = new Date();
    const gameRecent =
      lastPlayedGame &&
      (now - toSeasonDate(lastPlayedGame.date)) / 86400000 <= RECENT_GAME_WINDOW_DAYS;

    // Postponed-today check first — this outranks everything else. Compares
    // calendar day only (toDateString ignores time-of-day), so it's true for
    // the entire original game date and false the moment it's tomorrow.
    const isPostponedToday =
      nextGame?.postponedFrom &&
      now.toDateString() === toSeasonDate(nextGame.postponedFrom).toDateString();

    if (isPostponedToday) {
      setState('postponed');
    } else if (gameRecent) {
      const galleryCoversGame =
        latestGallery && new Date(latestGallery.date) >= toSeasonDate(lastPlayedGame.date);
      setState(galleryCoversGame ? 'gallery' : 'final');
    } else {
      setState('next');
    }
    // Runs once on mount, same as a page load re-evaluating "today" fresh —
    // matches the component's original self-expiring behavior with no
    // timers, just moved off the render path.
  }, []);

  return (
    <section className={styles.hero}>
      {bgPhotoSrc ? (
        <Image src={bgPhotoSrc} alt={teamName} fill priority sizes="100vw" className={styles.heroImg} />
      ) : (
        <div aria-hidden="true" style={{ position: 'absolute', inset: 0, background: fallbackGradient }} />
      )}
      <div className={styles.scrim} />
      {watermarkSrc && (
        <Image
          src={watermarkSrc}
          alt={watermarkAlt}
          width={520}
          height={280}
          aria-hidden="true"
          className={styles.watermark}
        />
      )}

      {state === 'gallery' && (
        <div className={styles.content}>
          <span className={styles.eyebrow}>{opponentName(lastPlayedGame.opponent)} Game Gallery</span>
          <h1 className={styles.bigLine}>
            {latestGallery.photoCount ? `${latestGallery.photoCount} Photos` : 'Photos Are Live'}
          </h1>
          <a href={latestGallery.href} target="_blank" rel="noopener noreferrer" className={styles.cta}>View Gallery →</a>
        </div>
      )}

      {state === 'final' && (
        <div className={styles.content}>
          <span className={styles.eyebrow}>Final</span>
          {lastPlayedGame.result.usScore != null && lastPlayedGame.result.themScore != null ? (
            <div className={styles.scoreLine}>
              <span>{teamShortLabel} <strong>{lastPlayedGame.result.usScore}</strong></span>
              <span>{opponentName(lastPlayedGame.opponent)} <strong>{lastPlayedGame.result.themScore}</strong></span>
            </div>
          ) : (
            <h1 className={styles.bigLine}>
              {lastPlayedGame.result.win ? 'W' : 'L'} {lastPlayedGame.result.score} — {opponentName(lastPlayedGame.opponent)}
            </h1>
          )}
          <a href="#schedule" className={styles.cta}>Full Schedule →</a>
        </div>
      )}

      {state === 'postponed' && (
        <div className={styles.content}>
          <span className={styles.alertBadge}>⚠ Weather Postponement</span>
          <h1 className={styles.bigLine}>
            Moved to {nextGame.date}, {nextGame.time}
          </h1>
          <div className={styles.metaRow}>
            <span>{nextGame.home ? 'vs' : '@'} {opponentName(nextGame.opponent)} — originally tonight</span>
            <span className={styles.badge}>{nextGame.home ? 'Home' : 'Away'}</span>
            {nextGame.location && <span>{nextGame.location}</span>}
          </div>
          <a href="#schedule" className={styles.cta}>Full Schedule →</a>
        </div>
      )}

      {state === 'next' && (
        <div className={styles.content}>
          <span className={styles.eyebrow}>{nextGame ? 'Next Game' : '2026 Season Complete'}</span>
          {nextGame ? (
            <>
              <h1 className={styles.matchup}>
                {teamMatchupName}
                <span className={styles.vs}>{nextGame.home ? 'vs' : '@'}</span>
                {opponentName(nextGame.opponent)}
              </h1>
              <div className={styles.metaRow}>
                <span>{nextGame.date} · {nextGame.time}</span>
                <span className={styles.badge}>{nextGame.home ? 'Home' : 'Away'}</span>
                {nextGame.location && <span>{nextGame.location}</span>}
              </div>
              <a href="#schedule" className={styles.cta}>Game Day Info →</a>
            </>
          ) : (
            <a href="#schedule" className={styles.cta}>Full Schedule &amp; Results →</a>
          )}
        </div>
      )}
    </section>
  );
}
